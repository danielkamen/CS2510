import javalib.funworld.*;
import javalib.worldimages.*;
import tester.Tester;
import java.awt.Color;
import java.util.ArrayList;

//Represents an individual tile
class Tile {
  // The number on the tile.  Use 0 to represent the hole
  int value;

  // Draws this tile onto the background at the specified logical coordinates
  WorldImage drawAt(int col, int row, WorldImage background) { 
    return new OverlayOffsetImage(new RectangleImage(10, 10, "solid", Color.blue),
        30 * col, 30 * row, background);
  }
}

class FifteenGame extends World {
  // represents the rows of tiles
  ArrayList<ArrayList<Tile>> tiles;

  // draws the game
  public WorldScene makeScene() {

    WorldImage backdrop = new RectangleImage(120, 120, "solid", Color.white);

    for (int i = 0; i < 5; i ++) {
      for (int j = 0; j < 5; j++) {
        this.tiles.get(i).get(j).drawAt(i, j, backdrop);
      }
    }
    return null;
  }

  // handles keystrokes
  public void onKeyEvent(String k) {
    // needs to handle up, down, left, right to move the hole
    // extra: handle "u" to undo moves
    if (k.equals("left")) {
      // i really dont wanna make this many methods for a lab
    }

    else if (k.equals("right")) {
      // i really dont wanna make this many methods for a lab
    }

    else if (k.equals("up")) {
      // i really dont wanna make this many methods for a lab
    }

    else if (k.equals("down")) {
      // i really dont wanna make this many methods for a lab
    }

    else if (k.equals("u")) {
      // i really dont wanna make this many methods for a lab
    }

  }
}

class ExampleFifteenGame {
  void testGame(Tester t) {
    FifteenGame g = new FifteenGame();
    g.bigBang(120, 120);
  }
}